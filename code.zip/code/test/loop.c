#include "syscall.h"

int main()
{
	Exec("../test/loop");
	Exec("../test/loop");
	Exec("../test/loop");
}